#!/bin/sh
CLASSPATH="$CLASSPATH:$DITA_HOME/plugins/org.dita.pdf2/lib/fo.jar"
CLASSPATH="$CLASSPATH:$DITA_HOME/plugins/org.dita.pdf2.axf/lib/axf.jar"
CLASSPATH="$CLASSPATH:$DITA_HOME/plugins/org.dita.pdf2.xep/lib/xep.jar"
