// Dummy class to allow compiling against RenderX

package com.renderx.xep.lib;

public class ConfigurationException extends FormatterException {
    public ConfigurationException() {
    }
}
