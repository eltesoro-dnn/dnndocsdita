// Dummy class to allow compiling against RenderX

package com.renderx.xep;

import java.io.OutputStream;

public class FOTarget {
    public FOTarget(OutputStream var1, String var2) {
        throw new UnsupportedOperationException();
    }
}
