org.dita4publishers.xmldomain.doctypes
======================

Document types for the D4P XML domain. Note that this vocabulary is obsolete with DITA 1.3, which provides its own XML domain. This domain conflicts with the DITA 1.3 version and should not be used with DITA 1.3.