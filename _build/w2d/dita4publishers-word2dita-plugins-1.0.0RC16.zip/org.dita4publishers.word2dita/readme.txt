Unzip this so that the org.dita4publishers.word2dita subdirectory 
is a child of the DITA-OT plugins or demo directory (e.g. C:\DITA-OT\plugins\), and 
you should be ready to go. 

The input to this plugin is Word DOCX files. If you have DOC files you can use
the Microsoft-provided Office Migration Planning Manager (OMPM) to produce DOCX files
from DOC files (http://technet.microsoft.com/en-us/library/cc179179.aspx#section1)

NOTE: This project uses the DITA Community plugin org.dita-community.common.xslt as a git
submodule. 