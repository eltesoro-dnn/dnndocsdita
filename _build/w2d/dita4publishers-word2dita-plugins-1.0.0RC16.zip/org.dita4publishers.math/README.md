org.dita4publishers.math
======================

D4P MathML documents. Provides markup for equations and integrates
the W3C MathML vocabulary as a DITA foreign vocabulary. Note that
this domain is obsolete as of DITA 1.3 as DITA 1.3 provides its
own equation domain and integration of MathML as a foreign vocabulary. 