org.dita4publishers.doctypes
======================

Provides all the DITA for Publishers document type shells
and vocabulary modules. Also provides template documents.